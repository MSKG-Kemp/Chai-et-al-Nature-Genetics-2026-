# Analysis code for the GWAS data of "Multiscale analysis and functional validation of the cellular and genetic determinants of skeletal disease" by Chai et al.



# Scripts

* 03-Chai-et-al-Genomics-Code.txt is the script that contains functions used in the analysis of GWAS eBMD data
