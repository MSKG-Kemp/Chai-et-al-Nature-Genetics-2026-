# Analysis code for the human scRNA-seq data of "Multiscale analysis and functional validation of the cellular and genetic determinants of skeletal disease" by Chai et al.



# Scripts

* 01_Preprocessing_QC_clustering_human.Rmd is an R-script that contains functions used in the preprocessing, QC and clustering of all cells from the human scRNA-seq data
* 02_Label_transfer_mouse_and_human.Rmd is the R-script that contains functions used in the analysis to compare mouse and human scRNA-seq data
